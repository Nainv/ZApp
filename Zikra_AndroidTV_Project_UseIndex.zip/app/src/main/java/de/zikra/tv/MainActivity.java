package de.zikra.tv;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebResourceError;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.Collections;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean loadingLocalFallback = false;
    private static final String SITE_URL =
            "https://koukach91-hash.github.io/zikra-android-tv-new/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUi();

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF071525);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (url != null && url.startsWith("file:///android_asset/index.html")) {
                    loadingLocalFallback = true;
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                // Use the bundled index.html only if the main online page cannot load.
                if (request != null && request.isForMainFrame() && !loadingLocalFallback) {
                    loadingLocalFallback = true;
                    view.stopLoading();
                    view.loadUrl("file:///android_asset/index.html");
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                super.onReceivedHttpError(view, request, response);
                if (request != null && request.isForMainFrame()
                        && response != null && response.getStatusCode() >= 400
                        && !loadingLocalFallback) {
                    loadingLocalFallback = true;
                    view.stopLoading();
                    view.loadUrl("file:///android_asset/index.html");
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
    }

    private void loadLatestVersion() {
        if (webView == null) return;
        // Clear WebView's disk/memory cache and add a unique query so the main HTML
        // is revalidated whenever the app is opened or returns to the foreground.
        loadingLocalFallback = false;
        webView.clearCache(true);
        String freshUrl = SITE_URL + "?appRefresh=" + System.currentTimeMillis();
        webView.loadUrl(freshUrl);
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUi();
        loadLatestVersion();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript(
                "window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',bubbles:true,cancelable:true}));",
                null
            );
            return;
        }
        super.onBackPressed();
    }
}
