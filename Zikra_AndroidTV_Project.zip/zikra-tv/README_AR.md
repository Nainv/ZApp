# ذِكرى – Android TV

هذا مشروع Android TV بسيط يفتح موقع ذِكرى المنشور على GitHub Pages داخل تطبيق WebView، مع دعم أزرار الريموت الأساسية.

## بناء APK عبر GitHub Actions
1. ارفع محتويات هذا المجلد إلى جذر مستودع GitHub الحالي، مع الحفاظ على `index.html` الحالي للموقع أو نسخه إلى مجلد `site` غير مطلوب لهذا الغلاف.
2. افتح تبويب Actions.
3. اختر `Build Zikra Android TV APK` ثم `Run workflow`.
4. بعد نجاح البناء افتح نتيجة التشغيل ونزّل Artifact باسم `zikra-android-tv-apk`.
5. فك ZIP لتحصل على `app-debug.apk`.

ملاحظة: التطبيق يعتمد على اتصال الإنترنت وموقع GitHub Pages. هذا ملف تجريبي غير موقّع للنشر في المتجر. اختبره أولاً على جهازك.
